Aplicar los siguentes comandos


	sudo chmod -R 755 /usr/share/netdata/web/
	sudo chown -R netdata:netdata /usr/share/netdata/web/


Y en el archivo /etc/netdata/netdata.conf

    [web]
    web files owner = netdata
    web files group = netdata

    # by default do not expose the netdata port
    bind to = 0.0.0.0:19999
