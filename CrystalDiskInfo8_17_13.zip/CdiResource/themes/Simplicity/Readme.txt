Simplicity - Crystal Disk Info Theme

Designed by RejZoR
http://www.rejzor.tk
rejzor[at]protonmail.com

Theme based on "classic" theme with a touch of simplicity :)