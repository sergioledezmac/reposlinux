chmod 777 cfu/linux32/aipfwupdate cfu/linux32/aipfwfmt
chmod 777 cfu/linux64/aipfwupdate cfu/linux64/aipfwfmt
stty -echo
java -jar TCxPrinterConfig.jar "$@"
stty echo
