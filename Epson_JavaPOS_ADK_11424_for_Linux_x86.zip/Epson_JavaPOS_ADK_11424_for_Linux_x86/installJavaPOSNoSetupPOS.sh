#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:: Install EPSON JavaPOS files to your system.                                    ::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#!/bin/sh
mkdir -p -m a+w /opt/EpsonJavaPOS
cp -a ./JavaPOS/bin /opt/EpsonJavaPOS
cp -a ./JavaPOS/checkhealth /opt/EpsonJavaPOS
cp -a ./JavaPOS/lib /opt/EpsonJavaPOS
cp -a ./JavaPOS/xml /opt/EpsonJavaPOS
chmod a+x -R /opt/EpsonJavaPOS

mkdir -p /var/epson_javapos/pos/trace
mkdir -p /var/epson_javapos/pos/statistics
chmod a+w -R /var/epson_javapos
