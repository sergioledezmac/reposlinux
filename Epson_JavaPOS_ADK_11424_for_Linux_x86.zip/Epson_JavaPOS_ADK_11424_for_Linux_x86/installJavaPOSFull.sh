#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:: Install EPSON JavaPOS setting.                                                 ::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#!/bin/sh
OS_BIT=`uname -m`

#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:: Install EPSON JavaPOS files to your system.                                    ::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
mkdir -p -m a+w /opt/EpsonJavaPOS
cp -r ./JavaPOS/bin /opt/EpsonJavaPOS
cp -r ./JavaPOS/checkhealth /opt/EpsonJavaPOS
cp -r ./JavaPOS/lib /opt/EpsonJavaPOS
cp -r ./JavaPOS/SetupPOS /opt/EpsonJavaPOS
cp -r ./JavaPOS/xml /opt/EpsonJavaPOS
chmod a+x -R /opt/EpsonJavaPOS

mkdir -p /var/epson_javapos/pos/trace
mkdir -p /var/epson_javapos/pos/statistics
chmod a+w -R /var/epson_javapos

#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:: When sharing a printer with another driver (application), you need to          ::
#:: share the communication port. In this case, installation of PCS is necessary.  ::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
cd ./pcs
chmod g+x ./pcsinstall.sh
./pcsinstall.sh

cd ./PCSSetting
if [ $OS_BIT = "x86_64" ]; then
chmod g+x ./pcssetting64
./pcssetting64 ENABLE_REPLACE_TO_LOWER_MODEL Enable string
else
chmod g+x ./pcssetting32
./pcssetting32 ENABLE_REPLACE_TO_LOWER_MODEL Enable string
fi
