#!/bin/sh

create_pathname=./LogData

rm -R -f $create_pathname
mkdir $create_pathname

## log
cp -r /var/epson_javapos/pos/trace/*.log $create_pathname

## pcs
cp -r /var/epson_pcs/portcommunicationservice/ $create_pathname
cp -r /var/epson_pcs/devicecontrollog/ $create_pathname
