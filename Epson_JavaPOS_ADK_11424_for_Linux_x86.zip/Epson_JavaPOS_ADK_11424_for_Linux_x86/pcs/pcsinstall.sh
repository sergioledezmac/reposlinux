#!/bin/sh
shell_dir=$(cd $(dirname $0);pwd)

# Do not edit these lines
INSTALL_DIR=${PCS_INSTALL_DIR:-/opt/epson_pcs/portcommunicationservice}
SETTING_DIR=${PCS_SETTING_DIR:-/var/epson_pcs}
DOC_DIR="/usr/share/doc/packages/epson-port-communication-service"

# make directories
mkdir -p $INSTALL_DIR
mkdir -p $SETTING_DIR/portcommunicationservice
mkdir -p $DOC_DIR

# stop the daemon
if [ -e "/etc/systemd/system/epson_logsvcd" ]; then
	systemctl stop epson_logsvcd
fi
if [ -e "/etc/init.d/epson_devicecontrollogserviced" ]; then
	/etc/init.d/epson_devicecontrollogserviced stop
fi

if [ -e "/etc/systemd/system/epson_pcsvcd" ]; then
	systemctl stop epson_pcsvcd
fi
if [ -e "/etc/init.d/epson_pcsvcd" ]; then
	/etc/init.d/epson_pcsvcd stop
fi

# copy modules
install -m 644 rule/10-portcommunicationservice.rules /etc/udev/rules.d

os_bit=`uname -m`
test $os_bit = "x86_64"
if [ $? -eq 0 ]
then
	install -m 755 bin/64/* $INSTALL_DIR
else
	install -m 755 bin/32/* $INSTALL_DIR
fi

install -m 644 SELinux/* $INSTALL_DIR

ln -f -s $INSTALL_DIR/pcsvc /usr/sbin/portcommunicationserviced
ln -f -s $INSTALL_DIR/devicecontrollogservice /usr/sbin/devicecontrollogserviced

# copy setting files
install -m 644 setting/pcs.devicereplace $SETTING_DIR/portcommunicationservice
install -m 644 setting/pcs.portcapability $SETTING_DIR/portcommunicationservice
install -m 644 setting/linux_pcs.setting $SETTING_DIR/portcommunicationservice/pcs.setting

install -m 644 doc/* $DOC_DIR

# copy init scripts
if [ "$(pgrep -o systemd)" = "1" -a ! -e /etc/redhat-release ] ; then
	install -m 755 script/epson_pcsvcd.service /etc/systemd/system
	install -m 755 script/epson_logsvcd.service /etc/systemd/system
elif [ -e /etc/SuSE-release ] ; then
	install -m 755 script/suse_pcsvcd /etc/init.d/epson_pcsvcd
	install -m 755 script/suse_logd /etc/init.d/epson_devicecontrollogserviced
elif [ -e /etc/redhat-release ] ; then 
	install -m 755 script/redhat_pcsvcd /etc/init.d/epson_pcsvcd
	install -m 755 script/redhat_logd /etc/init.d/epson_devicecontrollogserviced
else
	install -m 755 script/ubuntu_pcsvcd /etc/init.d/epson_pcsvcd
	install -m 755 script/ubuntu_logd /etc/init.d/epson_devicecontrollogserviced
fi

# edit init scripts
if [ "$(pgrep -o systemd)" = "1" -a ! -e /etc/redhat-release ] ; then
	if [ -n "$PCS_SETTING_DIR" ] ; then
		sed -i -e "s!# Environment=PCS_SETTING_DIR=!Environment=\"PCS_SETTING_DIR=$PCS_SETTING_DIR\"!g" /etc/systemd/system/epson_pcsvcd.service
		sed -i -e "s!# Environment=PCS_SETTING_DIR=!Environment=\"PCS_SETTING_DIR=$PCS_SETTING_DIR\"!g" /etc/systemd/system/epson_logsvcd.service
	fi

	if [ -n "$PCS_INSTALL_DIR" ] ; then
		sed -i -e "s!# Environment=PCS_INSTALL_DIR=!Environment=\"PCS_INSTALL_DIR=$PCS_INSTALL_DIR\"!g" /etc/systemd/system/epson_pcsvcd.service
		sed -i -e "s!# Environment=PCS_INSTALL_DIR=!Environment=\"PCS_INSTALL_DIR=$PCS_INSTALL_DIR\"!g" /etc/systemd/system/epson_logsvcd.service
	fi
else
	if [ -n "$PCS_SETTING_DIR" ] ; then
		sed -i -e "s!# export PCS_SETTING_DIR=!export PCS_SETTING_DIR=$PCS_SETTING_DIR!g" /etc/init.d/epson_pcsvcd
		sed -i -e "s!# export PCS_SETTING_DIR=!export PCS_SETTING_DIR=$PCS_SETTING_DIR!g" /etc/init.d/epson_devicecontrollogserviced
	fi

	if [ -n "$PCS_INSTALL_DIR" ] ; then
		sed -i -e "s!# export PCS_INSTALL_DIR=!export PCS_INSTALL_DIR=$PCS_INSTALL_DIR!g" /etc/init.d/epson_pcsvcd
		sed -i -e "s!# export PCS_INSTALL_DIR=!export PCS_INSTALL_DIR=$PCS_INSTALL_DIR!g" /etc/init.d/epson_devicecontrollogserviced
	fi
fi

# install policy module
if [ -e /etc/selinux/targeted/policy/policy.24 ] ; then
	if [ -e /etc/fedora-release ] ; then
		semodule -i $INSTALL_DIR/pcs.fc14.pp
		restorecon -R -i $INSTALL_DIR
		restorecon -R -i $SETTING_DIR/portcommunicationservice
		restorecon -R -i $SETTING_DIR/devicecontrollog
		restorecon /etc/init.d/epson_devicecontrollogserviced
		restorecon /etc/init.d/epson_pcsvcd
	elif [ -e /etc/redhat-release ] ; then
		semodule -i $INSTALL_DIR/pcs.el6.pp
		restorecon -R -i $INSTALL_DIR
		restorecon -R -i $SETTING_DIR/portcommunicationservice
		restorecon -R -i $SETTING_DIR/devicecontrollog
		restorecon /etc/init.d/epson_devicecontrollogserviced
		restorecon /etc/init.d/epson_pcsvcd
	fi
elif [ -e /etc/selinux/targeted/policy/policy.21 ] ; then
	semodule -i $INSTALL_DIR/pcs.el5.pp
	restorecon -R -i $INSTALL_DIR
	restorecon -R -i $SETTING_DIR/portcommunicationservice
	restorecon -R -i $SETTING_DIR/devicecontrollog
	restorecon /etc/init.d/epson_devicecontrollogserviced
	restorecon /etc/init.d/epson_pcsvcd
elif [ -e /etc/selinux/targeted/policy/policy.29 ] ; then
	semodule -i $INSTALL_DIR/pcs.el7.pp
	restorecon -R -i $INSTALL_DIR
	restorecon -R -i $SETTING_DIR/portcommunicationservice
	restorecon -R -i $SETTING_DIR/devicecontrollog
	restorecon /etc/init.d/epson_devicecontrollogserviced
	restorecon /etc/init.d/epson_pcsvcd
fi


# add the daemon
if [ "$(pgrep -o systemd)" = "1" -a ! -e /etc/redhat-release ] ; then
	systemctl daemon-reload
	systemctl enable epson_pcsvcd.service
	systemctl enable epson_logsvcd.service
elif [ -e /etc/SuSE-release ] ; then
	/sbin/chkconfig epson_devicecontrollogserviced on
	/sbin/chkconfig epson_pcsvcd on
elif [ -e /etc/redhat-release ] ; then 
	/sbin/chkconfig --add epson_devicecontrollogserviced
	/sbin/chkconfig --add epson_pcsvcd
else
	update-rc.d epson_devicecontrollogserviced start 20 2 3 4 5 . stop 80 0 1 6 .
	update-rc.d epson_pcsvcd start 20 2 3 4 5 . stop 80 0 1 6 .
fi


# start the daemon
if [ "$(pgrep -o systemd)" = "1" -a ! -e /etc/redhat-release ] ; then
	systemctl start epson_pcsvcd.service
	systemctl start epson_logsvcd.service
else
	/etc/init.d/epson_devicecontrollogserviced start
	/etc/init.d/epson_pcsvcd start
fi
