#!/bin/sh
shell_dir=$(cd $(dirname $0);pwd)

# Do not edit these lines
INSTALL_DIR=${PCS_INSTALL_DIR:-/opt/epson_pcs/portcommunicationservice}
SETTING_DIR=${PCS_SETTING_DIR:-/var/epson_pcs}
DOC_DIR="/usr/share/doc/packages/epson-port-communication-service"

# stop the daemon
if [ -e "/etc/systemd/system/epson_pcsvcd" ]; then
	systemctl stop epson_pcsvcd
fi
if [ -e "/etc/init.d/epson_pcsvcd" ]; then
	/etc/init.d/epson_pcsvcd stop
fi

if [ -e "/etc/systemd/system/epson_logsvcd" ]; then
	systemctl stop epson_logsvcd
fi
if [ -e "/etc/init.d/epson_devicecontrollogserviced" ]; then
	/etc/init.d/epson_devicecontrollogserviced stop
fi


# remove the daemon
if [ "$(pgrep -o systemd)" = "1" -a ! -e /etc/redhat-release ] ; then
	systemctl disable epson_pcsvcd.service
	systemctl disable epson_logsvcd.service
elif [ -e /etc/SuSE-release ] ; then
	/sbin/chkconfig epson_devicecontrollogserviced off
	/sbin/chkconfig epson_pcsvcd off
elif [ -e /etc/redhat-release ] ; then 
	/sbin/chkconfig --del epson_devicecontrollogserviced
	/sbin/chkconfig --del epson_pcsvcd
else
	update-rc.d -f epson_devicecontrollogserviced remove
	update-rc.d -f epson_pcsvcd remove
fi

#uninstall policy module
if [ -e /etc/selinux ] ; then
	which semodule 1>/dev/null 2>&1
	if [ $? -eq 0 ] ; then
		semodule -r portcommunicationservice
	fi
fi

# remove init scripts
if [ "$(pgrep -o systemd)" = "1" -a ! -e /etc/redhat-release ] ; then
	rm /etc/systemd/system/epson_pcsvcd.service
	rm /etc/systemd/system/epson_logsvcd.service
else
	rm /etc/init.d/epson_pcsvcd
	rm /etc/init.d/epson_devicecontrollogserviced
fi

killall -s SIGKILL /usr/sbin/portcommunicationserviced 1>/dev/null 2>&1
killall -s SIGTERM /usr/sbin/devicecontrollogserviced 1>/dev/null 2>&1

# remove setting files
rm $SETTING_DIR/portcommunicationservice/pcs.devicereplace
rm $SETTING_DIR/portcommunicationservice/pcs.portcapability
rm $SETTING_DIR/portcommunicationservice/pcs.setting

if [ -e $SETTING_DIR/portcommunicationservice/pcs.properties ] ; then
	rm $SETTING_DIR/portcommunicationservice/pcs.properties
fi
if [ -e $SETTING_DIR/devicecontrollog/log.txt ] ; then
	rm $SETTING_DIR/devicecontrollog/log.txt
fi

BACKUP_LOG="std*.gz"

for f in `find "$SETTING_DIR/devicecontrollog" -name "$BACKUP_LOG"`
do
	rm -rf ${f}
done

if [ -e $SETTING_DIR/devicecontrollog/logd.socket ] ; then
	rm $SETTING_DIR/devicecontrollog/logd.socket
fi
if [ -e $SETTING_DIR/portcommunicationservice/pcsvc.socket ] ; then
	rm $SETTING_DIR/portcommunicationservice/pcsvc.socket
fi

rm -rf $DOC_DIR

# remove modules
unlink /usr/sbin/portcommunicationserviced
unlink /usr/sbin/devicecontrollogserviced

rm $INSTALL_DIR/devicecontrollogservice
rm $INSTALL_DIR/libdevicecontrollog.so
rm $INSTALL_DIR/libethernetio31.so
rm $INSTALL_DIR/libparallelio31.so
rm $INSTALL_DIR/libpcsif.so
rm $INSTALL_DIR/libportconfig.so
rm $INSTALL_DIR/libportconnector31.so
rm $INSTALL_DIR/libreplace.so
rm $INSTALL_DIR/libserialio31.so
rm $INSTALL_DIR/libusbio31.so
rm $INSTALL_DIR/pcsvc
rm $INSTALL_DIR/property-reader
rm $INSTALL_DIR/pcs.el5.pp
rm $INSTALL_DIR/pcs.el6.pp
rm $INSTALL_DIR/pcs.el7.pp
rm $INSTALL_DIR/pcs.fc14.pp

rm /etc/udev/rules.d/10-portcommunicationservice.rules

# delete directories
rmdir $SETTING_DIR/portcommunicationservice
rmdir $SETTING_DIR/devicecontrollog
rmdir $SETTING_DIR
rmdir $INSTALL_DIR
